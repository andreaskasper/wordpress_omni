<?php

namespace plugins\goo1\omni;

class core {
	
	public static function init() {
	
		
	}

}