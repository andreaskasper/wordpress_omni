<?php

namespace plugins\goo1\omni;

class SiteHealth {

    public static function init($tests) {
        return $tests;
    }

}