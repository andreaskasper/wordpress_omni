<?php

use \plugins\goo1\omni\config;

/*if (!empty($_POST["act"]) AND $_POST["act"] == "save") {
    print_r($_POST);
    if (!empty($_POST["cloudflare_countriesadmin"])) {
        $a = preg_replace("@[^A-Z,]+@","", strtoupper($_POST["cloudflare_countriesadmin"]));
        config::set("cloudflare_admin_country", $a);
    }
    $is_saved = true;
}*/





?><style>
@import url(https://library.goo1.de/fontawesome/5/css/all.min.css);
</style>
<h1>Spenden</h1>
<hr class="wp-header-end">

