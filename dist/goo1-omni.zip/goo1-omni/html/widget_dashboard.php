<div class="e-overview__feed">
	<h3 class="e-overview__heading" style="font-weight: bold; border-bottom: 1px solid #00000080;">Wichtige Ankündigungen &amp; Aktuelles</h3>
	<ul class="e-overview__posts">
		<!--<li class="e-overview__post">
			<a href="https://elementor.com/blog/showcase-august-2020/?utm_source=wp-overview-widget&amp;utm_medium=wp-dash&amp;utm_campaign=news-feed" class="e-overview__post-link" target="_blank">
			Elementor Sites of the Month – August 2020								</a>
			<p class="e-overview__post-description">Join us as we explore this month’s top websites built with Elementor. This showcase features websites from many countries around the world, such as an Argentinian bakery, a large French Vegan online store, personal wedding websites, and many more.</p>
		</li>-->
	</ul>
</div>