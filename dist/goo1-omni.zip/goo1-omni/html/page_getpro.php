<?php

use \plugins\goo1\omni\config;

if (!empty($_POST["act"]) AND $_POST["act"] == "save") {
 
}





?><style>
@import url(https://library.goo1.de/fontawesome/5/css/all.min.css);
</style>
<h1>Erhalte Pro Features</h1>
<hr class="wp-header-end">
